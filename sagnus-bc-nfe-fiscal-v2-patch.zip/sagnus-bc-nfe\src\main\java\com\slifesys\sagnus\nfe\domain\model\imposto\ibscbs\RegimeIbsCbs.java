package com.slifesys.sagnus.nfe.domain.model.imposto.ibscbs;

public enum RegimeIbsCbs {
    REGULAR,
    REDUCAO_BASE,
    REDUCAO_ALIQUOTA,
    DIFERIMENTO,
    SUSPENSAO,
    ISENCAO,
    NAO_INCIDENCIA,
    IMUNIDADE
}