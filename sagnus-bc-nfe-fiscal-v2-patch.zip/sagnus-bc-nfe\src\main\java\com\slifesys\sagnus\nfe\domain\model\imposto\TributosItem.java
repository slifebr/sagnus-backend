package com.slifesys.sagnus.nfe.domain.model.imposto;

import com.slifesys.sagnus.nfe.domain.model.imposto.ibscbs.Cbs;
import com.slifesys.sagnus.nfe.domain.model.imposto.ibscbs.Ibs;

import java.util.Optional;

/**
 * Tributos do item da NFe.
 *
 * CompatÃ­vel com o construtor legado (ICMS/PIS/COFINS/IPI) e estendido no v2 com IBS/CBS.
 */
public class TributosItem {

    private final Icms icms;
    private final Pis pis;
    private final Cofins cofins;
    private final Ipi ipi;

    // V2 (reforma)
    private final Optional<Ibs> ibs;
    private final Optional<Cbs> cbs;

    // Construtor legado (mantÃ©m compatibilidade com o cÃ³digo existente)
    public TributosItem(Icms icms, Pis pis, Cofins cofins, Ipi ipi) {
        this(icms, pis, cofins, ipi, Optional.empty(), Optional.empty());
    }

    // Construtor v2
    public TributosItem(Icms icms, Pis pis, Cofins cofins, Ipi ipi, Optional<Ibs> ibs, Optional<Cbs> cbs) {
        this.icms = icms;
        this.pis = pis;
        this.cofins = cofins;
        this.ipi = ipi;
        this.ibs = ibs == null ? Optional.empty() : ibs;
        this.cbs = cbs == null ? Optional.empty() : cbs;
    }

    public Icms getIcms() { return icms; }
    public Pis getPis() { return pis; }
    public Cofins getCofins() { return cofins; }
    public Ipi getIpi() { return ipi; }

    public Optional<Ibs> getIbs() { return ibs; }
    public Optional<Cbs> getCbs() { return cbs; }
}